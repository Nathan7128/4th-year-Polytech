#include "ObjetGraphiqueFixe.h"



ObjetGraphiqueFixe::ObjetGraphiqueFixe(int i, int j, int type) :ObjetGraphique(i, j, type) {
}