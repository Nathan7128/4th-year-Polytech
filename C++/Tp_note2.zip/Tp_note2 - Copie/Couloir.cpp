#include "Couloir.h"



Couloir::Couloir(int i, int j):ObjetGraphiqueFixe(i, j, 2) {
}

void Couloir::afficher() {
	cout << " ";
}