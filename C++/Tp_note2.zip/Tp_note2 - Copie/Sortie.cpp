#include "Sortie.h"



Sortie::Sortie(int i, int j):ObjetGraphiqueFixe(i, j, 3) {
}

void Sortie::afficher() {
	cout << "S";
}